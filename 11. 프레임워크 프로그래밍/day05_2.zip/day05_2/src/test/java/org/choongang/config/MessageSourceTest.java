package org.choongang.config;

public class MessageSourceTest {
}
