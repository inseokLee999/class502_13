package org.choongang.member.validators;

public class LoginValidator {
}
